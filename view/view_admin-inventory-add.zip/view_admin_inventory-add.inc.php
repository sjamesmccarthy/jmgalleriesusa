 <?php

    /* Check for Session, Parse Session into vars */
    if($this->checkSession()) {
        $loginInfo = json_decode( $_SESSION['data'], true );
        extract($loginInfo, EXTR_PREFIX_SAME, "dup");
    } else {
        header('location:/studio/signin');
    }

    /* Get Supplier_Materials */
    $supplier_materials_data = $this->api_Admin_Get_Inventory_Supplier_Materials();
    
        if( count($supplier_materials_data) > 0) {
            $materials_html .= "<option>--manual entry</option>";
            foreach( $supplier_materials_data as $key => $val) {
                $materials_html .= '<option value="' . $val['supplier_materials_id'] . '" ';
                $materials_html .= 'data-unit="' . $val['unit_type'] . '" ';
                $materials_html .= 'data-inv="' . $val['quantity_bought'] . '"';
                $materials_html .= 'data-cost="' . $val['cost'] . '">';
                $materials_html .= $val['material_type'] . ", " . $val['material_desc'] . ', (' . $val['supplier'] . ') [' . $val['unit_type'] . ']';
                $materials_html .= '</option>';
            }
    }

    /* CHECK TO SEE IF THIS IS AN EDIT OR ADD NEW */
    if(isSet($this->routes->URI->queryvals)) {
        
        $edit_id = $this->routes->URI->queryvals[1];

        $edit_data = $this->api_Admin_Get_Inventory_Item($edit_id);
        extract($edit_data, EXTR_PREFIX_SAME, "dup");

        /* Fetch locations history data */
        $locationsHistory_data = $this->api_Admin_Get_Locations_History($edit_id);
        

        if( count($locationsHistory_data) > 0) {

            foreach( $locationsHistory_data as $key_lh => $val_lh) {

                if($val_lh['date_started'] != $val_lh['date_ended']) {
                    $location_history_html .= "-" . strtoupper($val_lh['location']) . " from " . date("F d, Y", strtotime($val_lh['date_started'])) . " to " . date("F d, Y", strtotime($val_lh['date_ended'])) . "<br />";
                } else {
                    if($val_lh['location'] == "COLLECTOR") {
                        $val_lh['location'] = $val_lh['location'] . ' (' . $val_lh['last_name'] . ')';
                    }
                    $location_history_html .= "<b>Currently located at " . $val_lh['location'] . " since " . date("F d, Y", strtotime($val_lh['date_started'])) . "</b><br />";
                } 
            }

            $location_history = '<a class="view-lh" href="#">view location history</a><div class="lh_container">' . $location_history_html . '</div>';
        } 

        $coa_data = $this->api_Admin_Get_Inventory_COA($edit_id);
        $edit_data['coa'] = $coa_data;

        if( count($edit_data['coa']) > 0) {

            foreach( $edit_data['coa'] as $key => $val) {
                $coa_html = "<div class='coa_list coa_list_found'><p class='coa-icon'><i class='fas fa-award'></i></p><p>" . $val['coa_first_name'] . " " . $val['coa_last_name'] . "<br />Certificate of Authenticity issued on " . date("F d, Y", strtotime($val['coa_purchase_date'])) . "</p></div>";
            }

        } else {
            $coa_html = "<p class='coa_list'>No COAs fround for this artwork, perhaps it hasn't been sold yet.</p>";
        }

        /* Costs for Art */
        $costs_data = $this->api_Admin_Get_Inventory_Item_Costs($edit_id);
        // $this->printp_r($costs_data);

        if($this->api['table'] == 'art_costs') {
            if( count($costs_data > 0) ) {

                $x=1;
                foreach( $costs_data as $row => $vals ) {  
                    foreach( $costs_data[0] as $key => $val) {
                        $x++;
                        $costs_html .= '<div class="supplier_materials"><div class="AUTO_GENERATED-- manual-entry material_expense_supplier-' . $x . '-manual-entry half-size show"><input type="text" id="material_expense_supplier-' . $x . '-manual-entry" name="material_expense_supplier-' . $x . '-manual-entry" placeholder="MANUAL ENTRY" value="' . $key . '"></div> <input data-exp="' . $x . '" class="width-auto material_quan" type="text" id="material_quantity-' . $x . '" name="material_quantity-' . $x . '" placeholder="QUANTITY" value="1" > <input data-exp="' . $x . '" class="width-auto material_quan" type="text" id="material_cost-' . $x . '" name="material_cost-' . $x . '" placeholder="$" value="' . $val . '" ><span class="remove-add"><i data-exp="' . $x . '" class="fas fa-times"></i></span></div>';
                    } 
                }

            } else {
                $costs_html = "<p class=''>No costs found for this artwork. (tbl:" . $this->api['table'] . ")</p>";
            }
        } else {

            // $this->printp_r($costs_data);

            $x=1;
// outer loop for the cost_data
foreach( $costs_data as $key_sc => $val_sc) {

            $costs_html .= '<div class="supplier_materials"><div class="material_expense_supplier-' . $x . '-container material_expense_supplier_container select-wrapper half-size">';
            $costs_html .= "<select name='material_expense_supplier-" . $x . "' attr=" . $x . " >";
            // $costs_html .= "<option value='manual'>--- manual entry</option>";

            foreach( $supplier_materials_data as $key_a => $val_a) {
                    
                if($val_a['supplier_materials_id'] == $val_sc['supplier_materials_id']) { $SELECTED = 'SELECTED'; } else { $SELECTED = null; }

                $materials_html_a .= '<option ' . $SELECTED . ' value="' . $val_a['material_desc'] . '" ';
                $materials_html_a .= 'data-unit="' . $val_a['unit_type'] . '" ';
                $materials_html_a .= 'data-inv="' . $val_a['quantity_bought'] . '"';
                $materials_html_a .= 'data-cost="' . $val_a['cost'] . '">';
                $materials_html_a .= $val_a['material_type'] . ", " . $val_a['material_desc'] . ', (' . $val_a['supplier'] . ') [' . $val_a['unit_type'] . ']';
                $materials_html_a .= '</option>';
                }
            $costs_html .= $materials_html_a;
            $costs_html .= "</select>";
            $costs_html .= "</div>";

            $costs_html .= '<input  data-exp="' . $x . '" class="width-auto material_quan" type="text" id="material_quantity-' . $x . '" name="material_quantity-' . $x . '" placeholder="QUANTITY" value="' . $val_sc['material_used'] . '"> <input  data-exp="' . $x . '" class="width-auto material_quan" type="text" id="material_cost-' . $x . '" name="material_cost-' . $x . '" placeholder="$" value="' . $val_sc['calcd_cost'] . '" ><span class="remove-add"><i data-exp="' . $x . '" class="fas fa-times"></i></span></div>';
            $x++;
            $materials_html_a = null;
        }
    }
        $page_title = "Editing <b>" . $title . "</b> finished artwork.";
        $formTypeAction = "update";
        $button_label="update artwork: " . $title;
        $button_archive_cancel = '<a class="cancel-button" href="/studio/inventory">cancel</a>';
        $id_field = '<input type="hidden" name="art_id" value="' . $art_id . '" />';
        $this->nav_label_inventory = "Updating Artwork";
        if($edit_data['reg_num'] == "" ) { $reg_num = strtotime($edit_data['born_date']); }
        $born_date = date("Y-m-d H:i:s", strtotime($edit_data['born_date']));
    } else {
        $formTypeAction = "insert";
        $button_label = "add new artwork";
        $page_title = "Adding <b>New Artwork</b> to Inventory";
        $button_archive_cancel = '<a class="cancel-button" href="/studio/inventory">cancel</a>';
        $this->nav_label_inventory = "Adding Artwork";
        $reg_num = time();
        $born_date = date("Y-m-d H:i:s", $reg_num);
    }

    /* CATALOG INDEX */
    $navigation_html = $this->component('admin_navigation');


    /* LOCATIONS INDEX */
    $location_data = $this->api_Admin_Get_Locations('all');

    foreach($location_data as $key_loc => $val_loc) {

        /* If Editing an existing record */
        if($val_loc['art_location_id'] === $edit_data['art_location_id']) { 
            $selected = "SELECTED"; 
            $hidden_location_id = '<input type="hidden" name="location_id_state" id="location_id_state" value="' . $edit_data['art_location_id'] . '">';
        } 
        else { $selected = null; }

        $location_html .= '<option ' . $selected . ' value="' . $val_loc['art_location_id'] . '">' . $val_loc['location'] . '</option>';
    }

    /* COLLECTORS INDEX */
    $collector_data = $this->api_Admin_Get_Collectors_List();
    // $this->printp_r($collector_data);

    foreach($collector_data as $key_col => $val_col) {

        /* If Editing an existing record */
        if($val_col['collector_id'] === $edit_data['collector_id']) { 
            $selected = "SELECTED"; 
            $hidden_collector_id = '<input type="hidden" name="collector_id_state" id="collector_id_state" value="' . $edit_data['collector_id_state'] . '">';
        } 
        else { $selected = null; }

        if(!empty($val_col['company']) ) {
            $company = $val_col['company'];
                if( !empty($val_col['first_name']) ) { 
                    $company = ' (' . $val_col['company'] . ')';
                }
        } else {
            $company = null;
        }

        $collector_html .= '<option ' . $selected . ' value="' . $val_col['collector_id'] . '">' . $val_col['first_name'] . ' ' . $val_col['last_name'] .  $company . '</option>';
    }


?>